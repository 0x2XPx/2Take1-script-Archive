--[[
	Save Table to File/Stringtable
	Load Table from File/Stringtable
	v 0.94
	
	Lua 5.1 compatible
	
	Userdata and indices of these are not saved
	Functions are saved via string.dump, so make sure it has no upvalues
	References are saved
	----------------------------------------------------
	table_lua.save( table [, filename] )
	
	Saves a table so it can be called via the table_lua.load function again
	table must a object of type 'table'
	filename is optional, and may be a string representing a filename or true/1
	
	table_lua.save( table )
		on success: returns a string representing the table (stringtable)
		(uses a string as buffer, ideal for smaller tables)
	table_lua.save( table, true or 1 )
		on success: returns a string representing the table (stringtable)
		(uses io.tmpfile() as buffer, ideal for bigger tables)
	table_lua.save( table, "filename" )
		on success: returns 1
		(saves the table to file "filename")
	on failure: returns as second argument an error msg
	----------------------------------------------------
	table_lua.load( filename or stringtable )
	
	Loads a table that has been saved via the table_lua.save function
	
	on success: returns a previously saved table
	on failure: returns as second argument an error msg
	----------------------------------------------------
	
	chillcode, http://lua-users.org/wiki/SaveTableToFile
	Licensed under the same terms as Lua itself.
]]--
local table_lua = {}
do local function a(b)b=string.format("%q",b)b=string.gsub(b,"\\\n","\\n")b=string.gsub(b,"\r","\\r")b=string.gsub(b,string.char(26),"\"..string.char(26)..\"")return b end;function table_lua.save(c,d)local e,f="   ","\n"local g,h;if not d then g={write=function(self,i)self.str=self.str..i end,str=""}e,f="",""elseif d==true or d==1 then e,f,g="","",io.tmpfile()else g,h=io.open(d,"w")if h then return _,h end end;local j,k={c},{[c]=1}g:write("return {"..f)for l,m in ipairs(j)do if d and d~=true and d~=1 then g:write("-- Table: {"..l.."}"..f)end;g:write("{"..f)local n={}for o,p in ipairs(m)do n[o]=true;if type(p)~="userdata"then if type(p)=="table"then if not k[p]then table.insert(j,p)k[p]=#j end;g:write(e.."{"..k[p].."},"..f)elseif type(p)=="function"then g:write(e.."loadstring("..a(string.dump(p)).."),"..f)else local q=type(p)=="string"and a(p)or tostring(p)g:write(e..q..","..f)end end end;for o,p in pairs(m)do if not n[o]and type(p)~="userdata"then if type(o)=="table"then if not k[o]then table.insert(j,o)k[o]=#j end;g:write(e.."[{"..k[o].."}]=")else local r=type(o)=="string"and"["..a(o).."]"or string.format("[%d]",o)g:write(e..r.."=")end;if type(p)=="table"then if not k[p]then table.insert(j,p)k[p]=#j end;g:write("{"..k[p].."},"..f)elseif type(p)=="function"then g:write("loadstring("..a(string.dump(p)).."),"..f)else local q=type(p)=="string"and a(p)or tostring(p)g:write(q..","..f)end end end;g:write("},"..f)end;g:write("}")if not d then return g.str.."--|"elseif d==true or d==1 then g:seek("set")return g:read("*a").."--|"else g:close()return 1 end end;function table_lua.load(s)local j,h,_;if string.sub(s,-3,-1)=="--|"then j,h=load(s)else j,h=loadfile(s)end;if h then return _,h end;j=j()for l=1,#j do local t,u={},{}for o,p in pairs(j[l])do if type(p)=="table"and j[p[1]]then table.insert(t,{o,j[p[1]]})end;if type(o)=="table"and j[o[1]]then table.insert(u,{o,j[o[1]]})end end;for _,p in ipairs(t)do j[l][p[1]]=p[2]end;for _,p in ipairs(u)do j[l][p[2]],j[l][p[1]]=j[l][p[1]],nil end end;return j[1]end end


return table_lua